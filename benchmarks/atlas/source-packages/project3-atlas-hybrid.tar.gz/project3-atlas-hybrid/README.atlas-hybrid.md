# Atlas 固定 12 核的 MPI+OpenMP 配比实验

本包接续已完成的 V3 进程强扩展作业 1027222。它保持总核数与问题规模不变，比较进程/线程配比，不使用前次作业的时间充当本次基线。

## 实验内容

| MPI 进程 P | 每进程线程 T | 总核数 P×T |
|---:|---:|---:|
| 1 | 12 | 12 |
| 2 | 6 | 12 |
| 3 | 4 | 12 |
| 4 | 3 | 12 |
| 6 | 2 | 12 |
| 12 | 1 | 12 |

固定 V3、Allreduce、N=1000000、D=32、K=32、seed=42。预热 2 轮后恢复初始中心，正式计时 20 轮。每组重复 5 次，每批打乱配置顺序，共 30 条正式记录。申请 12 核、8GB、30 分钟，数据在内存中生成。

`12×1` 在本作业内重新测量，作为纯进程配比参考。相对配比收益为 `median(12×1) / median(P×T)`；它不是增加核心数的加速比，不能再除以 12 当作强扩展效率。是否比较 V0 可另行安排，不混用不同作业的基线。

## 布局与核查

脚本先读取 PBS 实际分配的 OS CPU 与 socket/core 拓扑，要求恰好 12 个不同物理核心。按 socket、core 排序后，每个 rank 取得连续 T 个核心，所有 rank 不重叠且覆盖整个分配。

若仍分配两个 socket 各 6 核，则 12×1、6×2、4×3、2×6 的每个 rank 均可留在一个 socket 内；3×4 的中间 rank 和 1×12 的唯一 rank 跨 socket。若分配变化，以 `layout-plan.json` 的实际 `rank_sockets` 和 `cross_socket_ranks` 为准，不硬编码 CPU 编号。

为能明确表示跨 socket 配比，MPI 启动器使用 `--bind-to none`；随后每个 rank 的 Python 包装器立即限制自己的 OS CPU mask，并设置逐核显式 `OMP_PLACES` 和 `OMP_PROC_BIND=close`，再执行算法。不能把 MPI 自身的“unbound”提示解释成最终未绑核；要检查包装器记录的实际 OS mask。

每次运行前，包装器还执行一个独立的 OpenMP 小程序，记录每个探测线程的实际 CPU mask、当前 CPU、线程编号及 `_OPENMP` 标准版本宏；要求每线程绑定一个指定核心且线程间不重叠。探测程序和算法使用同一 GCC 及 OpenMP 编译选项。探测完成后，算法继承相同的 rank mask 和线程环境，并仍自行检查实际线程组大小。

线程记录来自运行前的独立探测程序，不是计时循环内的逐线程实时采样。探测开销不属于 `kernel_seconds`，但包含在外层 `launch_seconds` 中，因此外层启动时间不能与前次启动方式直接比较。

核查依据：[Linux CPU affinity 文档](https://www.man7.org/linux/man-pages/man2/sched_setaffinity.2.html)说明 affinity mask 在 exec 后保留；[GNU OpenMP places 文档](https://gcc.gnu.org/onlinedocs/gcc-11.5.0/libgomp/OMP_005fPLACES.html)说明显式 places 与核心绑定方式。

## 上传与提交

在 Mac 本地终端：

```bash
scp "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/project3-atlas-hybrid.tar.gz" ryanrui@atlas9.nus.edu.sg:
```

在 Atlas 终端：

```bash
mkdir -p "/hpctmp/$USER"
tar -xzf ~/project3-atlas-hybrid.tar.gz -C "/hpctmp/$USER"
cd "/hpctmp/$USER/project3-atlas-hybrid"
qsub atlas-hybrid.pbs
```

记下返回的 Job ID，使用 `qstat -u "$USER"` 查看状态。程序会先重新编译，再对全部 6 种布局执行小规模 V3/串行质心、标签、计数和 SSE 对照。布局或数值检查失败会停止；只有预检查通过后才正式计时。

结果目录为 `results/atlas-hybrid.<完整 Job ID>/`。例如作业是 `1234567.venus01`，检查：

```bash
qstat -xf 1234567.venus01
cat results/atlas-hybrid.1234567.venus01/status.txt
cat results/atlas-hybrid.1234567.venus01/experiment-check.json
```

预期退出状态为 0，30 条记录、6 组、5 次重复，数值及 placement 检查均 pass。若失败，读取 `p3_hybrid.o1234567`；预检查错误还会保存在 `preflight-p*.stderr.log`。

## 回收结果

在 Atlas 替换实际 Job ID 后执行：

```bash
qstat -xf 1234567.venus01 > results/atlas-hybrid.1234567.venus01/pbs-job.txt
cp p3_hybrid.o1234567 results/atlas-hybrid.1234567.venus01/
tar -czf ~/atlas-hybrid-results.tar.gz -C results atlas-hybrid.1234567.venus01
```

在 Mac 本地下载：

```bash
scp ryanrui@atlas9.nus.edu.sg:atlas-hybrid-results.tar.gz "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/"
```

核心文件：

- `hybrid.jsonl`、`hybrid.csv`：30 次原始结果、每组时间中位数及范围。
- `placements/launch-*/`：每次正式运行的 rank CPU mask、线程探测、启动命令和检查结论。每条原始结果通过 `placement_id` 关联该目录。
- `allocation.json`、`layout-plan.json`：实际分配及全部布局。
- `preflight-*.json`、`preflight-placements/`：小数据正确性与布局对照。
- `environment.txt`、`binaries.sha256`、PBS 主日志：环境、二进制哈希、完整编译命令。
- `experiment-check.json`、`status.txt`：完整性、数值与布局检查。

最终比较需标明哪些 rank 跨 socket。该实验能描述所分配硬件上的混合布局效果，不能单独隔离 MPI 进程数、线程合并成本和 NUMA 的全部影响，也不提供多节点结论。

## 本地验证范围

源码包不包含本地构建产物，算法源码未作修改。布局规划、错误拒绝、结果与 placement 目录关联通过本地 Python 测试；脚本通过 Bash 及 Python 3.8 语法检查。探测器在 Mac 上完成可移植分支编译检查；Linux affinity 分支、GCC 9.2.0 和集群 MPI 的实际组合需要本作业的计算节点预检查确认。
