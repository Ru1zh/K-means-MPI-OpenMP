# Atlas 单节点进程强扩展实验

前一轮 validation 已在 Atlas 完成，Exit_status=0。这个包用于下一轮受控计时，不会覆盖先前的 validation 目录。

## 测量范围

- V0 串行基线，加上 V3 的 1、2、3、4、6、12 个 MPI 进程。
- 每进程固定 1 个线程，V3 使用 allreduce；这不是 V1 的性能测量。
- 固定 N=1,000,000、D=32、K=32、seed=42，预热 2 轮后测量 20 轮。
- 每组重复 5 次，每批随机排列配置，共 7 组、35 条记录。
- 申请单节点 12 核、8 GB 内存、30 分钟；数据在内存中生成。

这轮只回答单节点 V3 随进程数增加如何变化。OpenMP 线程扩展、混合布局比较、通信方式比较和跨节点扩展需要分别测量。

## 上传与提交

在 Mac 本地终端上传：

```bash
scp "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/project3-atlas-strong.tar.gz" ryanrui@atlas9.nus.edu.sg:
```

在已经登录 Atlas 的终端执行：

```bash
mkdir -p "/hpctmp/$USER"
tar -xzf ~/project3-atlas-strong.tar.gz -C "/hpctmp/$USER"
cd "/hpctmp/$USER/project3-atlas-strong"
qsub atlas-strong.pbs
```

记下返回的完整 Job ID，例如 `1234567.venus01`，查询状态：

```bash
qstat -u "$USER"
qstat -xf 1234567.venus01
```

用实际 Job ID 替换示例。结束后检查 `Exit_status` 和 `p3_strong.o1234567`，仅状态为 F 不代表实验成功。

## 脚本执行过程

1. 在计算节点依次加载 miniconda/4.12、openmpi/4.1.2、gcc/9.2.0，并确认实际使用 GCC 9.2.0。指定 OMPI_CXX 后强制重新编译。
2. 读取 PBS 作业进程的 Linux CPU affinity 和 sysfs 拓扑。要求分配恰好 12 个不同的物理核心，否则停止。
3. 对每个进程数执行预检查：记录每个 rank 的实际 OS CPU 编号，要求单节点、每 rank 一个核心、核心在 PBS 分配内、rank 间不重叠，且 rank 0 在各配置中使用同一 CPU。
4. 用 taskset 将 V0 固定到该 rank 0 CPU。正式 MPI 测量沿用预检查的启动参数，并保留每次启动的 Open MPI binding report。
5. 汇总时间，并检查 35 条记录是否完整、数据指纹和初始中心是否一致、计数总和与 SSE 是否正确。

预检查记录的是当时的实际 affinity；正式测量另保留 MPI 绑核报告，回收后还需核对。若检查失败，查看日志并修正环境，不要绕过检查后直接将结果当作受控实验。

## 输出与下载

结果在 `results/atlas-strong.<完整 Job ID>/`：

- `status.txt`：应为 `exit_status=0`。
- `experiment-check.json`：完整性与数值检查结果。
- `strong.jsonl`、`strong.csv`：原始记录与每组时间中位数、最小值、最大值。
- `strong.stderr.log`：每次正式启动的 MPI 绑核报告和诊断信息。
- `allocation.json`、`affinity-p*.jsonl`、`affinity-verified.json`、`serial-affinity.json`：CPU 分配及预检查证据。
- `environment.txt`：节点、编译器、MPI、Python 与 CPU 信息。

结束后在 Atlas 打包，替换为实际 Job ID：

```bash
tar -czf ~/atlas-strong-results.tar.gz -C results atlas-strong.1234567.venus01
```

在 Mac 本地下载：

```bash
scp ryanrui@atlas9.nus.edu.sg:atlas-strong-results.tar.gz "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/"
```

回收后先检查绑核、数值一致性和每组 5 次记录，再计算 `V0 中位数 / V3 中位数` 的速度比。另用 V3(P=1) 作为同一实现的扩展基准，区分实现差异与进程扩展收益。不要仅凭 5 次结果将小幅差异解释为稳定优势。
