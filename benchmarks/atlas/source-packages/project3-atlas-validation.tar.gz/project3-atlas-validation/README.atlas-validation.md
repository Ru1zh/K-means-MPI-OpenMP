# Atlas: correctness validation and first CPU pilot

This bundle is for Project 3's existing C++17 MPI + OpenMP program. It uses one
Atlas PBS allocation: 12 CPU cores, 8 GB RAM, at most 30 minutes. No GPU or
external dataset is required. The program generates deterministic data in memory.

The job loads `miniconda/4.12`, then `openmpi/4.1.2`, then `gcc/9.2.0`. Loading GCC
last and setting `OMPI_CXX` preserves the compiler selection validated in the
successful smoke job. The Python module provided Python 3.8.5 in the first Atlas
validation attempt. The scripts now use Python-3.8-compatible syntax, and the
job checks for Python 3.8 or later; the updated run still needs verification on Atlas.

## Run

From the Mac terminal, upload `project3-atlas-validation.tar.gz` to
`ryanrui@atlas9.nus.edu.sg:`. Then, in the Atlas terminal:

```bash
mkdir -p "/hpctmp/$USER"
tar -xzf ~/project3-atlas-validation.tar.gz -C "/hpctmp/$USER"
cd "/hpctmp/$USER/project3-atlas-validation"
qsub atlas-validation.pbs
```

This is a new directory; the preceding smoke run and its logs are retained.
Each submission writes to `results/atlas-validation.<PBS_JOBID>/`.

## Stages

1. Check compiler/Python versions, record CPU topology, shell affinity, and PBS
   nodefile, then rebuild both binaries on the compute node.
2. Run the existing unittest suite with `TEST_MPI=1`. It currently contains 12
   test methods, including genuine MPI cases and comparisons of V0–V3 results.
   The shell stops if tests fail; no pilot measurements are then produced.
3. Attempt a bound 3-rank x 4-thread run and retain stdout plus binding reports.
   A launcher failure stops the job. A zero exit code alone does not prove the
   binding matches the allocation: inspect the saved reports and topology.
4. Run an exploratory pilot: N=100000, D=32, K=32, 20 measured iterations,
   2 warmup iterations, seed 42, 3 repeats per configuration. There are 9
   configurations (V0; and V1, V2, V3-Allreduce, V3-Reduce+Bcast at P=1 and P=3),
   hence 27 measurements. V1 uses one thread/rank; V2/V3 use four. Maximum CPU
   demand is 3 x 4 = 12 cores.

## Outputs to inspect

- PBS output: `p3_validate.o<job-number>`.
- `status.txt`: `exit_status=0` only when the job exits successfully.
- `correctness.log`: should end with `OK`, with no unexpectedly skipped MPI cases.
- `environment.txt`: compiler, Python, MPI, topology, allocation, and shell affinity.
- `binding-probe.json` / `binding-probe.stderr.log`: first bound run and reports.
- `pilot.jsonl`: raw timing, input fingerprint, counts, SSE, environment, and binary hashes.
- `pilot.stderr.log`: launcher commands, binding reports, and MPI warnings.
- `pilot.csv`: 9 rows of per-configuration medians/ranges with 3 repeats each.

The pilot is not the formal strong/weak/hybrid scaling experiment. In particular,
review serial baseline affinity, MPI bindings versus scheduler allocation, CPU
model, timing variability and data/result consistency first. Do not mix timings
from different machines or compiler configurations into one speedup comparison.

If the job fails, read the PBS output and the last stage's log. Do not use partial
pilot data as a completed experiment. Preserve the results before scratch cleanup.
