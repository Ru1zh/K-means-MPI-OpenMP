# Atlas 后续两组正式对照

这两个包已经准备好，尚未在 Atlas 执行。算法 C++ 主源码取自同一个 Code 目录，每个压缩包保留打包时的完整副本、数据配置和校验清单，可以独立上传、解压和提交。

## 默认实验矩阵

固定 N=1000000、D=32、K=32、seed=42、20 轮计时、2 轮预热；每配置重复 5 次。每个作业都使用单节点 12 核、8GB、30 分钟。

| 作业 | 配比 P×T | 对照 | 正式记录数 |
|---|---|---|---:|
| threads | 2×6、4×3、6×2 | V2 原子更新 vs V3 线程私有缓冲，均为 Allreduce | 30 |
| communication | 2×6、4×3、6×2 | V3 Allreduce vs V3 Reduce+Bcast | 30 |

两种方案在每个 P/T 内交错执行、每轮随机排序。P/T 采用随机排列的分块顺序；没有将所有配比的所有方案做全局交错。主要比较应是同一 P/T 内的两种策略。

默认配比在前次“每 socket 6 核”的分配下都不会让单个 rank 跨 socket；实际分类以本作业 `layout-plan.json` 为准。可等待混合实验结果后选择配比。无需改源码，例如只跑 4×3：

```bash
qsub -v ATLAS_PROCESS_LIST=4 atlas-threads.pbs
```

若需指定多个进程数，提交参数使用冒号分隔，脚本会转换为进程列表：

```bash
qsub -v ATLAS_PROCESS_LIST=2:4:6 atlas-threads.pbs
```

有效 P 为 1、2、3、4、6、12，对应 T=12/P。若选择全部六种配比，每个作业将产生 60 条正式记录。新增跨 socket 配比时应另行标记布局影响。

## 数据准备

数据规格保存在 `atlas-data-spec.json`：使用程序自带的确定性合成生成器，各 rank 按全局样本编号在内存中生成，无需下载或上传大型数据文件。默认值由该文件提供；实际执行配置另保存于 `study-plan.json`。

`atlas-threads-plan.json` 和 `atlas-communication-plan.json` 是提交前的默认矩阵预览，不包含任何实测性能值。浮点数学库可能影响合成值，作业内通过 `data_fingerprint` 和初始中心编号核对输入，不能仅凭相同种子就宣称跨环境的数据逐位一致。

每个作业先做所有选定策略的小数据对照，再生成一次同规模 V0 结果作为数值参考。这个 V0 只运行一次，不能作为正式重复计时基线。正式记录与本作业的 V0 参考比较 SSE，并输出小数据质心、SSE 的误差数值。

## 独立上传和提交

### V2/V3 对照

Mac 本地终端：

```bash
scp "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/project3-atlas-threads.tar.gz" ryanrui@atlas9.nus.edu.sg:
```

Atlas 终端：

```bash
mkdir -p "/hpctmp/$USER"
tar -xzf ~/project3-atlas-threads.tar.gz -C "/hpctmp/$USER"
cd "/hpctmp/$USER/project3-atlas-threads"
qsub atlas-threads.pbs
```

### 通信方式对照

Mac 本地终端：

```bash
scp "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/project3-atlas-communication.tar.gz" ryanrui@atlas9.nus.edu.sg:
```

Atlas 终端：

```bash
tar -xzf ~/project3-atlas-communication.tar.gz -C "/hpctmp/$USER"
cd "/hpctmp/$USER/project3-atlas-communication"
qsub atlas-communication.pbs
```

脚本开始时验证 `source-manifest.sha256`，确认上传文件与打包时一致。若自行改了包内文件，校验会停止；应在主源码修订后生成一个新包和清单，保留旧包追溯。

## 结果与判断

分别保存到：

- `results/atlas-threads.<完整 Job ID>/`
- `results/atlas-communication.<完整 Job ID>/`

完成后检查 `status.txt` 为 `exit_status=0`，`experiment-check.json` 中数值和 placement 检查为 pass，记录数与实际选择匹配。不能只看 PBS 状态为 F。

| 文件 | 内容 |
|---|---|
| `study-plan.json` | 实际工作量、配比、顺序和预期记录数 |
| `reference-small.json`、`reference-large.json` | 本作业内生成的 V0 数值参考 |
| `preflight-check.json` | 小数据标签/计数一致性、最大质心绝对及缩放误差、SSE 误差 |
| `raw-p*.jsonl`、`raw-p*.stderr.log` | 各配比两种方案交错测量的原始记录和错误日志 |
| `raw.jsonl`、`summary.csv` | 全部正式记录和中位数/最小值/最大值 |
| `numerical-errors.json` | 每条正式记录相对本作业 V0 的 SSE 误差及簇计数一致性 |
| `comparisons.json` | 每个 P/T 的两方案时间统计、第二方案相对第一方案的中位数比 |
| `placements/` | 每次运行的 CPU mask、独立线程探测和检查，按 placement_id 关联原始记录 |
| `layout-plan.json`、`allocation.json` | CPU 分配和跨 socket 分类 |
| `source-check.txt`、`binaries.sha256`、`environment.txt` | 源码校验、二进制哈希和环境 |

`comparisons.json` 中，threads 的比值为 V2 时间/V3 时间；communication 为 Allreduce 时间/Reduce+Bcast 时间。大于 1 表示第二方案本次中位数较快。结合全部 5 次样本及范围分析，不能将小幅差异直接认定为稳定优势。

每次运行前的线程探测、CPU mask 和 kernel 时间之间的范围说明与混合作业相同：探测器是独立 OpenMP 小程序，记录不来自算法计时循环内；包装器启动开销包含在外部 launch_seconds 中。最终策略性能对比采用 kernel_seconds，阶段瓶颈需另行 profile。

## 回收示例

在对应 Atlas 作业目录，使用实际 kind、Job ID 和作业名替换示例：

```bash
qstat -xf 1234567.venus01 > results/atlas-threads.1234567.venus01/pbs-job.txt
cp p3_threads.o1234567 results/atlas-threads.1234567.venus01/
tar -czf ~/atlas-threads-results.tar.gz -C results atlas-threads.1234567.venus01
```

Mac 本地下载：

```bash
scp ryanrui@atlas9.nus.edu.sg:atlas-threads-results.tar.gz "/Users/admin/Desktop/DSS/DSA5208/Project/Project 3/HPC/"
```

通信作业的 kind 为 `communication`，PBS 作业名为 `p3_comm`，主日志形如 `p3_comm.o1234567`。

## 验证范围

本地验证包括矩阵覆盖、数值误差计算与错误拒绝、启动器记录关联、原实验工具回归测试、Shell/Python 3.8 语法和压缩包内容检查。没有在本地伪造 Atlas 性能数据。新作业的 Linux/MPI/OpenMP 实际组合仍由 Atlas 计算节点上的预检查确认；当前混合作业尚待回收核对。

可选的弱扩展和阶段 profile 功能已存在于主程序/实验工具中，本次没有额外打包或提交这些补充实验。
